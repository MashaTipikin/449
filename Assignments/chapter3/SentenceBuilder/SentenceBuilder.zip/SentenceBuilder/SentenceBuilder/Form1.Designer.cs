﻿namespace SentenceBuilder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bigAbutton = new System.Windows.Forms.Button();
            this.smallAbutton = new System.Windows.Forms.Button();
            this.bigAnButton = new System.Windows.Forms.Button();
            this.smallAnButton = new System.Windows.Forms.Button();
            this.bigTheButton = new System.Windows.Forms.Button();
            this.smallTheButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedButton = new System.Windows.Forms.Button();
            this.modeButton = new System.Windows.Forms.Button();
            this.spokeButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.laughButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationButton = new System.Windows.Forms.Button();
            this.answerLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bigAbutton
            // 
            this.bigAbutton.Location = new System.Drawing.Point(18, 18);
            this.bigAbutton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bigAbutton.Name = "bigAbutton";
            this.bigAbutton.Size = new System.Drawing.Size(98, 52);
            this.bigAbutton.TabIndex = 0;
            this.bigAbutton.Text = "A";
            this.bigAbutton.UseVisualStyleBackColor = true;
            this.bigAbutton.Click += new System.EventHandler(this.bigAbutton_Click);
            // 
            // smallAbutton
            // 
            this.smallAbutton.Location = new System.Drawing.Point(124, 18);
            this.smallAbutton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.smallAbutton.Name = "smallAbutton";
            this.smallAbutton.Size = new System.Drawing.Size(98, 52);
            this.smallAbutton.TabIndex = 1;
            this.smallAbutton.Text = "a";
            this.smallAbutton.UseVisualStyleBackColor = true;
            this.smallAbutton.Click += new System.EventHandler(this.smallAbutton_Click);
            // 
            // bigAnButton
            // 
            this.bigAnButton.Location = new System.Drawing.Point(231, 18);
            this.bigAnButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bigAnButton.Name = "bigAnButton";
            this.bigAnButton.Size = new System.Drawing.Size(98, 52);
            this.bigAnButton.TabIndex = 2;
            this.bigAnButton.Text = "An";
            this.bigAnButton.UseVisualStyleBackColor = true;
            this.bigAnButton.Click += new System.EventHandler(this.bigAnButton_Click);
            // 
            // smallAnButton
            // 
            this.smallAnButton.Location = new System.Drawing.Point(338, 18);
            this.smallAnButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.smallAnButton.Name = "smallAnButton";
            this.smallAnButton.Size = new System.Drawing.Size(98, 52);
            this.smallAnButton.TabIndex = 3;
            this.smallAnButton.Text = "an";
            this.smallAnButton.UseVisualStyleBackColor = true;
            this.smallAnButton.Click += new System.EventHandler(this.smallAnButton_Click);
            // 
            // bigTheButton
            // 
            this.bigTheButton.Location = new System.Drawing.Point(444, 18);
            this.bigTheButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bigTheButton.Name = "bigTheButton";
            this.bigTheButton.Size = new System.Drawing.Size(98, 52);
            this.bigTheButton.TabIndex = 4;
            this.bigTheButton.Text = "The";
            this.bigTheButton.UseVisualStyleBackColor = true;
            this.bigTheButton.Click += new System.EventHandler(this.bigTheButton_Click);
            // 
            // smallTheButton
            // 
            this.smallTheButton.Location = new System.Drawing.Point(550, 18);
            this.smallTheButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.smallTheButton.Name = "smallTheButton";
            this.smallTheButton.Size = new System.Drawing.Size(98, 52);
            this.smallTheButton.TabIndex = 5;
            this.smallTheButton.Text = "the";
            this.smallTheButton.UseVisualStyleBackColor = true;
            this.smallTheButton.Click += new System.EventHandler(this.smallTheButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(18, 80);
            this.manButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(98, 52);
            this.manButton.TabIndex = 6;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(124, 80);
            this.womanButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(98, 52);
            this.womanButton.TabIndex = 7;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(231, 80);
            this.dogButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(98, 52);
            this.dogButton.TabIndex = 8;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(338, 80);
            this.catButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(98, 52);
            this.catButton.TabIndex = 9;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(444, 80);
            this.carButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(98, 52);
            this.carButton.TabIndex = 10;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(550, 80);
            this.bicycleButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(98, 52);
            this.bicycleButton.TabIndex = 11;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(18, 142);
            this.beautifulButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(98, 52);
            this.beautifulButton.TabIndex = 12;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(180, 142);
            this.bigButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(98, 52);
            this.bigButton.TabIndex = 13;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(393, 142);
            this.smallButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(98, 52);
            this.smallButton.TabIndex = 14;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(550, 142);
            this.strangeButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(98, 52);
            this.strangeButton.TabIndex = 15;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedButton
            // 
            this.lookedButton.Location = new System.Drawing.Point(18, 203);
            this.lookedButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookedButton.Name = "lookedButton";
            this.lookedButton.Size = new System.Drawing.Size(98, 52);
            this.lookedButton.TabIndex = 16;
            this.lookedButton.Text = "looked at";
            this.lookedButton.UseVisualStyleBackColor = true;
            this.lookedButton.Click += new System.EventHandler(this.lookedButton_Click);
            // 
            // modeButton
            // 
            this.modeButton.Location = new System.Drawing.Point(124, 203);
            this.modeButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.modeButton.Name = "modeButton";
            this.modeButton.Size = new System.Drawing.Size(98, 52);
            this.modeButton.TabIndex = 17;
            this.modeButton.Text = "rode";
            this.modeButton.UseVisualStyleBackColor = true;
            this.modeButton.Click += new System.EventHandler(this.modeButton_Click);
            // 
            // spokeButton
            // 
            this.spokeButton.Location = new System.Drawing.Point(286, 203);
            this.spokeButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.spokeButton.Name = "spokeButton";
            this.spokeButton.Size = new System.Drawing.Size(98, 52);
            this.spokeButton.TabIndex = 18;
            this.spokeButton.Text = "spoke to";
            this.spokeButton.UseVisualStyleBackColor = true;
            this.spokeButton.Click += new System.EventHandler(this.spokeButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(550, 203);
            this.droveButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(98, 52);
            this.droveButton.TabIndex = 19;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // laughButton
            // 
            this.laughButton.Location = new System.Drawing.Point(444, 203);
            this.laughButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.laughButton.Name = "laughButton";
            this.laughButton.Size = new System.Drawing.Size(98, 52);
            this.laughButton.TabIndex = 20;
            this.laughButton.Text = "laughed at";
            this.laughButton.UseVisualStyleBackColor = true;
            this.laughButton.Click += new System.EventHandler(this.laughButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(180, 265);
            this.spaceButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(98, 52);
            this.spaceButton.TabIndex = 21;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(286, 265);
            this.periodButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(98, 52);
            this.periodButton.TabIndex = 22;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationButton
            // 
            this.exclamationButton.Location = new System.Drawing.Point(393, 265);
            this.exclamationButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.exclamationButton.Name = "exclamationButton";
            this.exclamationButton.Size = new System.Drawing.Size(98, 52);
            this.exclamationButton.TabIndex = 23;
            this.exclamationButton.Text = "!";
            this.exclamationButton.UseVisualStyleBackColor = true;
            this.exclamationButton.Click += new System.EventHandler(this.exclamationButton_Click);
            // 
            // answerLabel
            // 
            this.answerLabel.AutoSize = true;
            this.answerLabel.Location = new System.Drawing.Point(18, 369);
            this.answerLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(0, 20);
            this.answerLabel.TabIndex = 24;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(140, 394);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(112, 35);
            this.exitButton.TabIndex = 25;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(18, 394);
            this.clearButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(112, 35);
            this.clearButton.TabIndex = 26;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.exclamationButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.laughButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.spokeButton);
            this.Controls.Add(this.modeButton);
            this.Controls.Add(this.lookedButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.smallTheButton);
            this.Controls.Add(this.bigTheButton);
            this.Controls.Add(this.smallAnButton);
            this.Controls.Add(this.bigAnButton);
            this.Controls.Add(this.smallAbutton);
            this.Controls.Add(this.bigAbutton);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bigAbutton;
        private System.Windows.Forms.Button smallAbutton;
        private System.Windows.Forms.Button bigAnButton;
        private System.Windows.Forms.Button smallAnButton;
        private System.Windows.Forms.Button bigTheButton;
        private System.Windows.Forms.Button smallTheButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedButton;
        private System.Windows.Forms.Button modeButton;
        private System.Windows.Forms.Button spokeButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button laughButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationButton;
        private System.Windows.Forms.Label answerLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button clearButton;
    }
}

